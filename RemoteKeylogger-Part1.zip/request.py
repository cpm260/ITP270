#!/usr/bin/env python3

import requests

form_url="https://docs.google.com/forms/u/0/d/e/1FAIpQLSdVoqWpwJ9VSLuHM9F8e5HxlIl9JompiEERqNO5WFE_w6W6zA/formResponse"

form_id="mG61Hd"

form_data ={ 'entry.839337160':'This is a test'}

r = requests.post(form_url, data=form_data)
